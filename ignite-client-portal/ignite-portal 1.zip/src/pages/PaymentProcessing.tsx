import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PortalLayout } from "@/components/layout/PortalLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, CreditCard, ArrowLeft, ExternalLink, AlertCircle, CheckCircle2 } from "lucide-react";
import { toast } from '@/hooks/use-toast';
import { EffectiveDateSelector } from "@/components/payment/EffectiveDateSelector";
import { format } from "date-fns";
import { savePendingOnboarding } from "@/hooks/useOnboardingResume";

export default function PaymentProcessing() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  const franchiseeId = searchParams.get("franchisee_id");
  const success = searchParams.get("success");
  const canceled = searchParams.get("canceled");
  const customerType = searchParams.get("customer_type") === "existing" ? "existing" : "new";
  
  const [isCreatingCheckout, setIsCreatingCheckout] = useState(false);
  const [checkoutUrl, setCheckoutUrl] = useState<string | null>(null);
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const [isBypassingExistingCustomer, setIsBypassingExistingCustomer] = useState(false);

  // Fetch franchisee details (include portal for effective-date settings)
  const { data: franchisee, isLoading } = useQuery({
    queryKey: ["franchisee-payment", franchiseeId],
    queryFn: async () => {
      if (!franchiseeId) return null;
      const { data, error } = await supabase
        .from("franchisees")
        .select("*, brands(*, portals(*)), plans(*)")
        .eq("id", franchiseeId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!franchiseeId,
  });

  // Handle success/cancel redirects
  useEffect(() => {
    if (success === "true") {
      toast.success("Payment setup successful!");
      navigate(`/confirmation?franchisee_id=${franchiseeId}`);
    } else if (canceled === "true") {
      toast.error("Payment was canceled. Please try again.");
    }
  }, [success, canceled, franchiseeId, navigate]);

  // Redirect if no franchisee ID
  useEffect(() => {
    if (!franchiseeId && !isLoading) {
      toast.error("Missing franchisee information");
      navigate("/select-brand");
    }
  }, [franchiseeId, isLoading, navigate]);

  // Existing customers on existing-customer-enabled plans bypass effective date selection and Stripe.
  useEffect(() => {
    if (!franchisee || success === "true" || isBypassingExistingCustomer) return;

    const shouldBypassStripe =
      customerType === "existing" &&
      franchisee.brands?.existing_customer_logic === true;

    if (!shouldBypassStripe) return;

    const bypassStripe = async () => {
      setIsBypassingExistingCustomer(true);
      try {
        const { error } = await supabase
          .from("franchisees")
          .update({
            service_start_date: "2026-01-01",
            onboarding_step: "intake",
            payment_status: "authorized",
          })
          .eq("id", franchisee.id);

        if (error) throw error;

        savePendingOnboarding(franchisee.id, franchisee.brand_id, franchisee.plan_id);
        navigate(`/onboarding?franchisee_id=${franchisee.id}`, { replace: true });
      } catch (error: unknown) {
        console.error("Error bypassing existing customer payment:", error);
        const message = error instanceof Error ? error.message : "Failed to continue to onboarding";
        toast.error(message);
        setIsBypassingExistingCustomer(false);
      }
    };

    void bypassStripe();
  }, [franchisee, success, isBypassingExistingCustomer, navigate, customerType]);

  const handleCreateCheckout = async () => {
    if (!franchisee || !effectiveDate) return;

    setIsCreatingCheckout(true);

    try {
      // Call the edge function to create checkout session
      const { data, error } = await supabase.functions.invoke("create-checkout", {
        body: {
          franchiseeId: franchisee.id,
          planId: franchisee.plan_id,
          includePaidMedia: franchisee.include_paid_media,
          effectiveDate: effectiveDate.toISOString(),
           // Let the backend function decide the success URL (it includes CHECKOUT_SESSION_ID)
           // and routes the user through /payment-confirmation to wait for webhook confirmation.
           cancelUrl: `${window.location.origin}/payment-processing?franchisee_id=${franchisee.id}&canceled=true`,
        },
      });

      if (error) throw error;
      
      // Check for error in response body (edge function returns { error: "message" } on failure)
      if (data?.error) {
        throw new Error(data.error);
      }

      if (data?.url) {
        // Save franchisee ID for resume capability
        savePendingOnboarding(franchisee.id, franchisee.brand_id, franchisee.plan_id);
        
        setCheckoutUrl(data.url);
        // Redirect to Stripe Checkout
        window.location.href = data.url;
      } else {
        throw new Error("No checkout URL returned");
      }
    } catch (error: unknown) {
      console.error("Error creating checkout:", error);
      const message = error instanceof Error ? error.message : "Failed to create checkout session";
      toast.error(message);
    } finally {
      setIsCreatingCheckout(false);
    }
  };

  const handleBack = () => {
    // Go back to plan selection
    if (franchisee?.brand_id) {
      const params = new URLSearchParams({ brand_id: franchisee.brand_id });
      if (customerType === 'existing') params.set('customer_type', customerType);
      navigate(`/select-plan?${params.toString()}`);
    } else {
      navigate('/select-brand');
    }
  };

  if (isLoading || isBypassingExistingCustomer) {
    return (
      <PortalLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </PortalLayout>
    );
  }

  // Show success state if coming back from successful payment
  if (success === "true") {
    return (
      <PortalLayout>
        <div className="content-max px-4 py-8">
          <div className="flex flex-col items-center justify-center min-h-[60vh]">
            <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
            <p className="text-lg text-muted-foreground">Completing your setup...</p>
          </div>
        </div>
      </PortalLayout>
    );
  }

  const setupFee = franchisee?.plans?.setup_fee ? Number(franchisee.plans.setup_fee) : 0;
  const baseMonthly = franchisee?.plans?.monthly_price ? Number(franchisee.plans.monthly_price) : 0;
  const mediaAddonAmount = franchisee?.plans?.monthly_price_with_media ? Number(franchisee.plans.monthly_price_with_media) : 0;
  const showMedia = !!franchisee?.include_paid_media;
  // monthly_price_with_media is ADD-ON amount, so total = base + add-on
  const monthlyDue = showMedia && mediaAddonAmount > 0 ? baseMonthly + mediaAddonAmount : baseMonthly;

  return (
    <PortalLayout>
      <div className="content-max px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          {/* Hide back button once payment is confirmed — plan is locked in */}
          {!['paid', 'authorized', 'trialing'].includes(franchisee?.payment_status ?? '') && (
            <Button
              variant="ghost"
              onClick={handleBack}
              className="mb-4 -ml-2 text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Plan Selection
            </Button>
          )}
          
          <h1 className="text-page-title text-foreground mb-2">
            Complete Payment Setup
          </h1>
          <p className="text-body text-muted-foreground">
            Select your subscription start date and set up payment
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Left Column - Date Selection & Payment */}
          <div className="space-y-6">
            {/* Effective Date Selection */}
            <EffectiveDateSelector
              selectedDate={effectiveDate}
              onSelect={setEffectiveDate}
              minDate={franchisee?.brands?.portals?.effective_date_min ?? undefined}
              optionCount={franchisee?.brands?.portals?.effective_date_option_count ?? undefined}
            />

            {/* Payment Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-primary" />
                  Payment Information
                </CardTitle>
                <CardDescription>
                  {setupFee > 0 
                    ? `One-time setup fee of $${setupFee.toLocaleString()} will be charged today. Monthly subscription starts on your effective date.`
                    : "Your card will be saved and the monthly subscription will start on your effective date."
                  }
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {canceled === "true" && (
                  <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-destructive mt-0.5" />
                    <div>
                      <p className="font-medium text-destructive">Payment Canceled</p>
                      <p className="text-sm text-muted-foreground">
                        Your payment setup was canceled. Please try again.
                      </p>
                    </div>
                  </div>
                )}

                <div className="space-y-4">
                  <div className="p-4 bg-muted/30 rounded-lg space-y-3">
                    <div className="flex items-center gap-2 text-sm">
                        <CheckCircle2 className="h-4 w-4 text-primary" />
                      <span>Plan selected and confirmed</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                        <CheckCircle2 className="h-4 w-4 text-primary" />
                      <span>Secure payment via Stripe</span>
                    </div>
                    {effectiveDate && (
                      <div className="flex items-center gap-2 text-sm">
                          <CheckCircle2 className="h-4 w-4 text-primary" />
                        <span>Subscription starts {format(effectiveDate, 'MMMM d, yyyy')}</span>
                      </div>
                    )}
                  </div>

                  <Button
                    size="lg"
                    className="w-full"
                    onClick={handleCreateCheckout}
                    disabled={isCreatingCheckout || !effectiveDate}
                  >
                    {isCreatingCheckout ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Creating Checkout...
                      </>
                    ) : !effectiveDate ? (
                      "Select an Effective Date to Continue"
                    ) : (
                      <>
                        Continue to Payment
                        <ExternalLink className="h-4 w-4 ml-2" />
                      </>
                    )}
                  </Button>

                  <p className="text-xs text-center text-muted-foreground">
                    You will be redirected to Stripe's secure payment page
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Summary */}
          <Card className="border-primary/20 bg-primary/5 h-fit">
            <CardHeader>
              <CardTitle className="text-lg">Subscription Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {franchisee?.brands && (
                <div className="flex items-center gap-3 pb-4 border-b border-border">
                  {franchisee.brands.logo_url && (
                    <img
                      src={franchisee.brands.logo_url}
                      alt={franchisee.brands.name}
                      className="h-10 w-auto object-contain"
                    />
                  )}
                  <div>
                    <p className="font-medium">{franchisee.brands.name}</p>
                    <p className="text-sm text-muted-foreground">{franchisee.name}</p>
                  </div>
                </div>
              )}

              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Plan:</span>
                  <span className="font-medium">{franchisee?.plans?.name}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Monthly Fee:</span>
                  <span className="font-bold text-lg">
                    ${monthlyDue.toLocaleString()}/mo
                  </span>
                </div>

                {franchisee?.include_paid_media && mediaAddonAmount > 0 && (
                  <div className="flex justify-between pt-2 border-t">
                    <span className="text-muted-foreground">Paid Media Add-on:</span>
                    <span className="font-medium text-primary">
                      +${mediaAddonAmount.toLocaleString()}/mo
                    </span>
                  </div>
                )}

                {setupFee > 0 && (
                  <div className="flex justify-between pt-2 border-t">
                    <span className="text-muted-foreground">One-Time Setup Fee:</span>
                    <span className="font-medium">${setupFee.toLocaleString()}</span>
                  </div>
                )}

                {effectiveDate && (
                  <div className="flex justify-between pt-2 border-t">
                    <span className="text-muted-foreground">Effective Date:</span>
                    <span className="font-medium">{format(effectiveDate, 'MMM d, yyyy')}</span>
                  </div>
                )}
              </div>

              <div className="pt-4 border-t space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Due Today:</span>
                  <span className="font-bold text-xl">
                    ${setupFee > 0 ? setupFee.toLocaleString() : '0.00'}
                  </span>
                </div>
                {setupFee === 0 && (
                  <p className="text-xs text-muted-foreground">
                    Your card will be saved. First charge on your effective date.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PortalLayout>
  );
}
